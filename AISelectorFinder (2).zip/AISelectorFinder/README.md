# AI-Powered CSS Selector Finder

A focused, AI-powered tool that finds CSS selectors on web pages using known selectors defined in YAML configuration files.

## 🎯 Overview

This tool simplifies the process of finding CSS selectors for web elements by:
- Using AI to analyze page structure and known selectors
- Validating found selectors with Playwright
- Managing selectors through YAML configuration files
- Providing clean, simple output

## 🚀 Features

- **AI-Powered Analysis**: Uses OpenAI to intelligently find CSS selectors
- **YAML Configuration**: Manage known selectors in version-controllable YAML files
- **Playwright Validation**: Automatically validates found selectors
- **Clean Output**: Simple, focused results without unnecessary complexity
- **Hard-coded Configuration**: Simple to use with default settings

## 📦 Dependencies

- **Microsoft.Playwright**: Browser automation and validation
- **Microsoft.SemanticKernel**: AI integration with OpenAI
- **YamlDotNet**: YAML configuration parsing
- **AngleSharp**: HTML sanitization

## 🗂️ Project Structure

```
AISelectorFinder/
├── Program.cs                 # Main entry point with hard-coded options
├── SelectorFinder.cs          # Core selector finding logic
├── YamlSelectorLoader.cs      # YAML configuration loader
├── SelectorFinderOptions.cs   # Configuration options
├── SelectorRegistry.cs        # Simplified selector management
├── KnownSelector.cs           # Selector data model
├── HtmlSanitizer.cs          # HTML sanitization utilities
└── selectors.yaml            # YAML configuration file
```

## ⚙️ Configuration

### YAML Configuration File (`selectors.yaml`)

```yaml
selectors:
  - elementName: "login button"
    selector: "#login-button"
    url: "https://www.saucedemo.com/v1/"
    description: "Login button on the login page"
    type: "ID"
    isRequired: true
```

### Environment Variables

- `OPENAI_API_KEY`: Your OpenAI API key (required)

### Default Settings

The application uses the following hard-coded defaults:
- **Target URL**: `https://www.saucedemo.com/v1/`
- **Element Description**: `"login button"`
- **YAML Config**: `selectors.yaml`
- **OpenAI Model**: `gpt-4`
- **Headless Browser**: `true`
- **Timeout**: `30 seconds`

## 🎯 Usage

### Running the Application

```bash
dotnet run --project AISelectorFinder
```

Or build and run:

```bash
dotnet build AISelectorFinder
dotnet run --project AISelectorFinder
```

### What It Does

1. Loads selectors from `selectors.yaml`
2. Navigates to `https://www.saucedemo.com/v1/`
3. Searches for a "login button" element
4. Uses AI to find the CSS selector
5. Validates the selector with Playwright
6. Outputs the result

## 📋 Output

### Success Example

```
✅ Selector Found: #login-button
   Tag: INPUT
   Text: Login
   Visible: True
   Enabled: True
```

### Failure Example

```
❌ Selector Not Found
   Message: No selector found for the specified element
```

## 🔧 Development

### Building

```bash
dotnet build AISelectorFinder
```

### Running

```bash
dotnet run --project AISelectorFinder
```

## 🎯 Core Workflow

1. **Load Configuration**: Read selectors from YAML file
2. **Navigate**: Use Playwright to load target URL
3. **Sanitize**: Clean HTML using HtmlSanitizer
4. **AI Query**: Use OpenAI to find selector based on known selectors and page structure
5. **Validate**: Verify selector works with Playwright
6. **Return**: CSS selector or "NOT_FOUND"

## 🧹 What Was Removed

- All complex agent architecture
- JavaScript functionality
- Dependency injection complexity
- Plugin system
- Multi-step agent workflows
- Function calling complexity

## 🎯 Benefits

- **Simplified Codebase**: Much cleaner and easier to understand
- **Better Configuration**: YAML-based, version-controllable selectors
- **Focused Purpose**: Single responsibility - finding CSS selectors
- **Easier Maintenance**: Fewer dependencies and simpler logic
- **Better Usability**: Clear input/output with minimal overhead
- **No Configuration Required**: Just run and it works with sensible defaults

## 📝 License

This project is part of the AI-Powered CSS Selector Finder toolset. 