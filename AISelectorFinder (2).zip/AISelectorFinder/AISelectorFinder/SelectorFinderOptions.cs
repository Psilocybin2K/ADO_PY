namespace AISelectorFinder
{
    public class SelectorFinderOptions
    {
        public string TargetUrl { get; set; } = string.Empty;
        public string ElementDescription { get; set; } = string.Empty;
        public string YamlConfigPath { get; set; } = "selectors.yaml";
        public string OpenAIApiKey { get; set; } = string.Empty;
        public string OpenAIModel { get; set; } = "gpt-4";
        public bool HeadlessBrowser { get; set; } = false;
        public int TimeoutSeconds { get; set; } = 30;
        public bool VerboseOutput { get; set; } = false;
    }
} 