namespace AISelectorFinder
{
    using AngleSharp;
    using AngleSharp.Dom;
    using AngleSharp.Html.Dom;
    using AngleSharp.Html.Parser;

    public static class HtmlSanitizer
    {
        /// <summary>
        /// Sanitizes HTML by removing comments and attributes starting with underscore
        /// </summary>
        /// <param name="html">The HTML content to sanitize</param>
        /// <returns>Sanitized HTML content</returns>

        public static async Task<string> SanitizeAsync(string html)
        {
            IConfiguration config = Configuration.Default;
            IBrowsingContext context = BrowsingContext.New(config);
            IHtmlParser parser = context.GetService<IHtmlParser>() ?? throw new Exception("IHtmlParser is not available");

            AngleSharp.Html.Dom.IHtmlDocument document = await parser.ParseDocumentAsync(html);

            // Remove comment nodes
            List<IComment> comments = document.Descendants<IComment>().ToList();
            List<IHtmlStyleElement> styles = document.Descendants<IHtmlStyleElement>().ToList();
            List<IHtmlScriptElement> scripts = document.Descendants<IHtmlScriptElement>().ToList();
            foreach (IComment? comment in comments)
            {
                comment.Remove();
            }

            foreach (IHtmlStyleElement? style in styles)
            {
                style.Remove();
            }

            foreach (IHtmlScriptElement? script in scripts)
            {
                script.Remove();
            }

            // Remove attributes starting with underscore
            List<IElement> elements = document.Descendants<IElement>().ToList();
            foreach (IElement? element in elements)
            {
                List<IAttr> attributesToRemove = element.Attributes
                    .Where(attr => attr.Name.StartsWith("_"))
                    .ToList();

                foreach (IAttr? attr in attributesToRemove)
                {
                    element.RemoveAttribute(attr.Name);
                }
            }

            return document.DocumentElement.OuterHtml;
        }

        /// <summary>
        /// Sanitizes HTML synchronously
        /// </summary>
        /// <param name="html">The HTML content to sanitize</param>
        /// <returns>Sanitized HTML content</returns>
        public static string Sanitize(string html)
        {
            return SanitizeAsync(html).GetAwaiter().GetResult();
        }
    }
}