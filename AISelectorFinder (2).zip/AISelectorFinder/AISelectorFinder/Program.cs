﻿namespace AISelectorFinder
{
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using Microsoft.SemanticKernel;

    using System.Text;

    internal class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                // Create options
                SelectorFinderOptions options = new SelectorFinderOptions
                {
                    TargetUrl = "https://www.saucedemo.com/v1/",
                    ElementDescription = "login button",
                    YamlConfigPath = "selectors.yaml",
                    OpenAIApiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY") ??
                        throw new InvalidOperationException("OPENAI_API_KEY environment variable is required"),
                    OpenAIModel = "gpt-4",
                    HeadlessBrowser = true,
                    TimeoutSeconds = 30,
                    VerboseOutput = false
                };

                // Setup dependency injection
                IHost host = CreateHostBuilder(args, options).Build();

                // Get services from DI container
                using IServiceScope scope = host.Services.CreateScope();
                Kernel kernel = scope.ServiceProvider.GetRequiredService<Kernel>();
                IBrowserService browserService = scope.ServiceProvider.GetRequiredService<IBrowserService>();
                ILogger<Program> logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();

                logger.LogInformation("🚀 Starting CSS Selector Finder...");
                logger.LogInformation($"Target: {options.ElementDescription} on {options.TargetUrl}");

                // Navigate to the target URL
                await browserService.NavigateToUrlAsync(options.TargetUrl);

                // Get page HTML
                string sanitizedHtml = await browserService.GetPageHtmlAsync();

                // Load known selectors
                YamlSelectorLoader yamlLoader = new YamlSelectorLoader();
                List<KnownSelector> knownSelectors = yamlLoader.LoadSelectorsFromFile(options.YamlConfigPath);
                List<KnownSelector> relevantSelectors = knownSelectors
                    .Where(s => s.Url.Equals(options.TargetUrl, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                // Generate prompt
                string prompt = GeneratePrompt(options.ElementDescription, relevantSelectors, sanitizedHtml);

                // Invoke kernel directly
                FunctionResult result = await kernel.InvokePromptAsync(prompt);
                string? foundSelector = result.GetValue<string>();

                // Validate and output result
                bool validationResult = await ValidateAndPrintResult(browserService, foundSelector);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
                Environment.Exit(1);
            }
        }

        static IHostBuilder CreateHostBuilder(string[] args, SelectorFinderOptions options) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((context, services) =>
                {
                    services.AddLogging(builder => builder.AddConsole());

                    // Register options
                    services.AddSingleton(options);

                    // Register Semantic Kernel
                    services.AddSingleton<Kernel>(provider =>
                    {
                        return Kernel.CreateBuilder()
                            .AddOpenAIChatCompletion(options.OpenAIModel, options.OpenAIApiKey)
                            .Build();
                    });

                    // Register browser service as singleton
                    services.AddSingleton<IBrowserService, BrowserService>();
                });

        private static string GeneratePrompt(string elementDescription, List<KnownSelector> knownSelectors, string sanitizedHtml)
        {
            string knownSelectorsReport = GenerateKnownSelectorsReport(knownSelectors);

            return $$"""
                Based on the following known selectors report and page HTML, find the CSS selector for the element: "{{elementDescription}}"

                KNOWN SELECTORS REPORT:
                {{knownSelectorsReport}}

                PAGE HTML SOURCE (Sanitized):
                {{sanitizedHtml}}

                TASK: Find the CSS selector for the "{{elementDescription}}" element.

                INSTRUCTIONS:
                1. Analyze the known selectors report above
                2. Examine the page HTML source to understand the page structure
                3. Look for any element matching "{{elementDescription}}" in both the report and HTML
                4. Extract the exact CSS selector for that element
                5. If multiple matching elements exist, choose the most appropriate one
                6. Ensure the selector is valid CSS syntax and matches an element in the HTML

                REQUIREMENTS:
                - Return ONLY the CSS selector
                - Do not include any explanations or additional text
                - If no matching element is found, return "NOT_FOUND"
                - The selector should be the most specific and reliable one available
                - The selector must correspond to an actual element in the provided HTML

                FORMAT: Return a single line with just the CSS selector.
                """;
        }

        private static string GenerateKnownSelectorsReport(List<KnownSelector> selectors)
        {
            if (selectors.Count == 0)
            {
                return "No known selectors available for this URL.";
            }

            System.Text.StringBuilder report = new StringBuilder();
            report.AppendLine("KNOWN SELECTORS:");

            foreach (KnownSelector selector in selectors)
            {
                report.AppendLine($"- {selector.ElementName}: {selector.Selector} ({selector.Description})");
            }

            return report.ToString();
        }

        private static async Task<bool> ValidateAndPrintResult(IBrowserService browserService, string? foundSelector)
        {
            if (string.IsNullOrEmpty(foundSelector) || foundSelector == "NOT_FOUND")
            {
                Console.WriteLine($"❌ Selector Not Found");
                Console.WriteLine($"   Message: No selector found for the specified element");
                return false;
            }

            // Validate the selector
            ValidationResult validationResult = await browserService.ValidateSelectorAsync(foundSelector);

            if (validationResult.IsValid)
            {
                Console.WriteLine($"✅ Selector Found: {foundSelector}");
                Console.WriteLine($"   Tag: {validationResult.TagName}");
                Console.WriteLine($"   Text: {validationResult.TextContent}");
                Console.WriteLine($"   Visible: {validationResult.IsVisible}");
                Console.WriteLine($"   Enabled: {validationResult.IsEnabled}");
                return true;
            }
            else
            {
                Console.WriteLine($"❌ Selector Found but Validation Failed: {foundSelector}");
                Console.WriteLine($"   Message: Selector found but validation failed");
                return false;
            }
        }
    }
}
