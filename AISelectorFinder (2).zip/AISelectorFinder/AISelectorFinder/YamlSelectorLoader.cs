namespace AISelectorFinder
{
    using YamlDotNet.Serialization;
    using YamlDotNet.Serialization.NamingConventions;

    public class YamlSelectorLoader
    {
        private readonly IDeserializer _deserializer;

        public YamlSelectorLoader()
        {
            _deserializer = new DeserializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();
        }

        public List<KnownSelector> LoadSelectorsFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"YAML configuration file not found: {filePath}");
            }

            try
            {
                string yamlContent = File.ReadAllText(filePath);
                SelectorConfiguration config = _deserializer.Deserialize<SelectorConfiguration>(yamlContent);

                if (config?.Selectors == null)
                {
                    throw new InvalidOperationException("Invalid YAML configuration: 'selectors' section is missing or empty");
                }

                ValidateSelectors(config.Selectors);
                return config.Selectors;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to load selectors from {filePath}: {ex.Message}", ex);
            }
        }

        public List<KnownSelector> LoadSelectorsFromMultipleFiles(params string[] filePaths)
        {
            List<KnownSelector> allSelectors = new List<KnownSelector>();

            foreach (string filePath in filePaths)
            {
                List<KnownSelector> selectors = LoadSelectorsFromFile(filePath);
                allSelectors.AddRange(selectors);
            }

            return allSelectors;
        }

        private void ValidateSelectors(List<KnownSelector> selectors)
        {
            foreach (KnownSelector selector in selectors)
            {
                if (string.IsNullOrWhiteSpace(selector.ElementName))
                {
                    throw new InvalidOperationException("Selector missing required 'elementName' field");
                }

                if (string.IsNullOrWhiteSpace(selector.Selector))
                {
                    throw new InvalidOperationException($"Selector '{selector.ElementName}' missing required 'selector' field");
                }

                if (string.IsNullOrWhiteSpace(selector.Url))
                {
                    throw new InvalidOperationException($"Selector '{selector.ElementName}' missing required 'url' field");
                }
            }
        }
    }

    public class SelectorConfiguration
    {
        public List<KnownSelector> Selectors { get; set; } = new();
    }
}