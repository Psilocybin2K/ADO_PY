namespace AISelectorFinder
{
    using Microsoft.Playwright;

    public class BrowserService : IBrowserService
    {
        private IPlaywright? _playwright;
        private IBrowser? _browser;
        private IPage? _page;
        private readonly SelectorFinderOptions _options;

        public BrowserService(SelectorFinderOptions options)
        {
            _options = options;
        }

        public async Task InitializeAsync()
        {
            if (_playwright == null)
            {
                _playwright = await Playwright.CreateAsync();
                _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
                {
                    Headless = _options.HeadlessBrowser
                });
                _page = await _browser.NewPageAsync();
            }
        }

        public async Task NavigateToUrlAsync(string url)
        {
            await InitializeAsync();

            if (_page == null)
            {
                throw new InvalidOperationException("Browser not initialized");
            }

            await _page.GotoAsync(url, new PageGotoOptions
            {
                WaitUntil = WaitUntilState.NetworkIdle,
                Timeout = _options.TimeoutSeconds * 1000
            });
        }

        public async Task<string> GetPageHtmlAsync()
        {
            if (_page == null)
            {
                throw new InvalidOperationException("Browser not initialized");
            }

            string pageSource = await _page.InnerHTMLAsync("html");
            return await HtmlSanitizer.SanitizeAsync(pageSource);
        }

        public async Task<ValidationResult> ValidateSelectorAsync(string selector)
        {
            if (_page == null)
            {
                throw new InvalidOperationException("Browser not initialized");
            }

            try
            {
                IElementHandle? element = await _page.QuerySelectorAsync(selector);

                if (element == null)
                {
                    return new ValidationResult { IsValid = false };
                }

                bool isVisible = await element.IsVisibleAsync();
                bool isEnabled = await element.IsEnabledAsync();
                string tagName = await element.EvaluateAsync<string>("el => el.tagName");
                string? textContent = await element.TextContentAsync();

                return new ValidationResult
                {
                    IsValid = true,
                    IsVisible = isVisible,
                    IsEnabled = isEnabled,
                    TagName = tagName,
                    TextContent = textContent?.Trim()
                };
            }
            catch
            {
                return new ValidationResult { IsValid = false };
            }
        }

        public void Dispose()
        {
            _page?.CloseAsync().Wait();
            _browser?.CloseAsync().Wait();
            _playwright?.Dispose();
        }
    }
}