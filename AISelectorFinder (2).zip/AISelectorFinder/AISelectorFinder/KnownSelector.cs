namespace AISelectorFinder
{
    using YamlDotNet.Serialization;

    public class KnownSelector
    {
        [YamlMember(Alias = "elementName")]
        public string ElementName { get; set; } = string.Empty;

        [YamlMember(Alias = "selector")]
        public string Selector { get; set; } = string.Empty;

        [YamlMember(Alias = "url")]
        public string Url { get; set; } = string.Empty;

        [YamlMember(Alias = "description")]
        public string Description { get; set; } = string.Empty;

        [YamlMember(Alias = "type")]
        public SelectorType Type { get; set; }

        [YamlMember(Alias = "isRequired")]
        public bool IsRequired { get; set; } = true;

        public KnownSelector()
        {
        }

        public KnownSelector(string elementName, string selector, string url, string description = "", SelectorType type = SelectorType.ID)
        {
            ElementName = elementName;
            Selector = selector;
            Url = url;
            Description = description;
            Type = type;
        }

        public string GetElementTypeDescription()
        {
            return Type switch
            {
                SelectorType.ID => "ID Selector",
                SelectorType.Class => "Class Selector",
                SelectorType.Attribute => "Attribute Selector",
                SelectorType.Child => "Child Selector",
                SelectorType.Descendant => "Descendant Selector",
                SelectorType.Element => "Element Selector",
                _ => "Unknown Selector"
            };
        }
    }

    public enum SelectorType
    {
        ID,
        Class,
        Attribute,
        Child,
        Descendant,
        Element
    }
}