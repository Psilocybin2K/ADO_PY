namespace AISelectorFinder
{
    public interface IBrowserService : IDisposable
    {
        Task NavigateToUrlAsync(string url);
        Task<string> GetPageHtmlAsync();
        Task<ValidationResult> ValidateSelectorAsync(string selector);
    }

    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public bool IsVisible { get; set; }
        public bool IsEnabled { get; set; }
        public string? TagName { get; set; }
        public string? TextContent { get; set; }
    }
} 