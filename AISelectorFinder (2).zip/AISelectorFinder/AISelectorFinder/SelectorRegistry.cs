namespace AISelectorFinder
{
    public class SelectorRegistry
    {
        private readonly List<KnownSelector> _knownSelectors = new();

        public IReadOnlyList<KnownSelector> KnownSelectors => _knownSelectors.AsReadOnly();

        public SelectorRegistry()
        {
        }

        public void LoadFromYaml(string yamlFilePath)
        {
            var loader = new YamlSelectorLoader();
            var selectors = loader.LoadSelectorsFromFile(yamlFilePath);
            _knownSelectors.Clear();
            _knownSelectors.AddRange(selectors);
        }

        public IEnumerable<KnownSelector> GetSelectorsForUrl(string url)
        {
            return _knownSelectors.Where(s => 
                s.Url.Equals(url, StringComparison.OrdinalIgnoreCase));
        }

        public IEnumerable<KnownSelector> GetSelectorsForUrlPattern(string urlPattern)
        {
            return _knownSelectors.Where(s => 
                s.Url.Contains(urlPattern, StringComparison.OrdinalIgnoreCase));
        }

        public KnownSelector? GetSelector(string elementName, string url)
        {
            return _knownSelectors.FirstOrDefault(s =>
                s.ElementName.Equals(elementName, StringComparison.OrdinalIgnoreCase) &&
                s.Url.Equals(url, StringComparison.OrdinalIgnoreCase));
        }

        public int GetTotalCount() => _knownSelectors.Count;
    }
}